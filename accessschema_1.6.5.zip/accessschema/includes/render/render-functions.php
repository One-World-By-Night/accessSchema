<?php

// File: includes/render/render-functions.php
// @version 1.6.0
// @author greghacke

defined( 'ABSPATH' ) || exit;

