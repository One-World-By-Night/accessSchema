<?php

// File: includes/core/bootstrap.php
// Text Domain: wp-plugin-name
// @vesion 1.0.0
// @author author
// Function: 

defined( 'ABSPATH' ) || exit;

define('WPPLUGINNAME_PATH', plugin_dir_path(__FILE__) . '../');
define('WPPLUGINNAME_URL', plugin_dir_url(__FILE__) . '../');