<?php

// File: includes/tools/_template.php
// Text Domain: wp-plugin-name
// @vesion 1.0.0
// @author author
// Function: 

defined( 'ABSPATH' ) || exit;