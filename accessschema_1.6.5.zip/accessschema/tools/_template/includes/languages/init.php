<?php

// File: includes/languages/init.php
// Text Domain: wp-plugin-name
// @vesion 1.0.0
// @author author
// Function: Init languages functionality for the plugin

defined( 'ABSPATH' ) || exit;

/** --- Require each language file once --- */
// require_once __DIR__ . '/_template.php';
