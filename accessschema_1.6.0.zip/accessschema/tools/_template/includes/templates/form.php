<?php

// File: includes/templates/form.php
// Text Domain: wp-plugin-name
// @vesion 1.0.0
// @author author
// Function: 

defined( 'ABSPATH' ) || exit;