<?php

// File: includes/utils/init.php
// Text Domain: wp-plugin-name
// @vesion 1.0.0
// @author author
// Function: Init utils functionality for the plugin

defined( 'ABSPATH' ) || exit;

/** --- Require each utils file once --- */
require_once __DIR__ . '/_template.php';