<?php

/** File: includes/tools/init.php
 * Text Domain: accessschema-client
 * version 1.2.0
 *
 * @author greghacke
 * Function: Init tools functionality for the plugin
 */

defined( 'ABSPATH' ) || exit;

/** --- Tools init (placeholder for future tools) --- */
