<?php

// File: accessschema-client/render-ui.php
// @version 1.5.0
// @author greghacke
// @tool accessschema-client

defined( 'ABSPATH' ) || exit;

