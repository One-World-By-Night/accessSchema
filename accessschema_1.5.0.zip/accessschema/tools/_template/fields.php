<?php

// File: tools/_template/fields.php
// @version 1.5.0
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;
