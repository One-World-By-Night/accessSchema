<?php

// File: includes/admin/settings.php
// @version 1.5.0
// @author greghacke

defined( 'ABSPATH' ) || exit;

