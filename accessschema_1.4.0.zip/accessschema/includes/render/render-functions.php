<?php

// File: includes/render/render-functions.php
// @version 1.4.0
// @author greghacke

defined( 'ABSPATH' ) || exit;

