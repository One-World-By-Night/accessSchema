<?php

// File: tools/_template/cpt.php
// @version 1.4.0
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

