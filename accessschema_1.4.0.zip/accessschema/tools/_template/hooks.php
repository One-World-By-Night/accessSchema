<?php

// File: tools/_template/hooks.php
// @version 1.4.0
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

