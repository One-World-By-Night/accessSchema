<?php

// File: tools/_template/hooks.php
// @version 1.0.1
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

