<?php

// File: includes/render/render-functions.php
// @version 1.0.1
// @author greghacke

defined( 'ABSPATH' ) || exit;

