<?php

/** File: prefix.php
 * Text Domain: accessschema-client
 * version 2.0.4
 *
 * @author greghacke
 * Function:
 */

defined( 'ABSPATH' ) || exit;

// Unique constant prefix for this embedded instance of accessSchema-client
define( 'ASC_PREFIX', 'WPVP' );       // Change 'YPP' to your plugin's unique prefix
define( 'ASC_LABEL', 'WPVP' );        // Change 'Your Plugin Label' to your plugin's label
