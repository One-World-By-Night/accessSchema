<?php

// File: tools/_template/fields.php
// @version 1.0.5
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;
