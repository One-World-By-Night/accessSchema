<?php

// File: tools/_template/cpt.php
// @version 1.0.5
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

