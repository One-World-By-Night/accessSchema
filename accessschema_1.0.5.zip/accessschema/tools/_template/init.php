<?php

// File: tools/_template/init.php
// @version 1.0.5
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

