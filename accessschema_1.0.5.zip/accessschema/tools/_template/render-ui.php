<?php

// File: tools/_template/render-ui.php
// @version 1.0.5
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

