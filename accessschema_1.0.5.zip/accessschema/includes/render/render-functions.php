<?php

// File: includes/render/render-functions.php
// @version 1.0.5
// @author greghacke

defined( 'ABSPATH' ) || exit;

