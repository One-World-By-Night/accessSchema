<?php

// File: includes/admin/settings.php
// @version 1.0.5
// @author greghacke

defined( 'ABSPATH' ) || exit;

