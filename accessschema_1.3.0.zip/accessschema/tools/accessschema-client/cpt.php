<?php

// File: accessschema-client/cpt.php
// @version 1.3.0
// @author greghacke
// @tool accessschema-client

defined( 'ABSPATH' ) || exit;

