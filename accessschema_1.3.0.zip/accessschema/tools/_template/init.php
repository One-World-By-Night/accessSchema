<?php

// File: tools/_template/init.php
// @version 1.3.0
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

