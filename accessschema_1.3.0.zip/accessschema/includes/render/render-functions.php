<?php

// File: includes/render/render-functions.php
// @version 1.3.0
// @author greghacke

defined( 'ABSPATH' ) || exit;

