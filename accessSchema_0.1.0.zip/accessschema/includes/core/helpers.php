<?php
// File: includes/core/helpers.php
// @version 0.1.0
// Author: greghacke

defined( 'ABSPATH' ) || exit;

// Setting default log level
function accessSchema_get_log_level() {
    $level = defined('ACCESS_SCHEMA_LOG_LEVEL') ? ACCESS_SCHEMA_LOG_LEVEL : 'INFO';
    return apply_filters('access_schema_log_level', $level);
}

/* Get the priority of a log level.
 *
 * @param string $level The log level (e.g. 'DEBUG', 'INFO', 'WARN', 'ERROR').
 * @return int Priority of the log level, lower is more important.
 */
function accessSchema_log_level_priority( $level ) {
    $levels = [
        'DEBUG' => 0,
        'INFO'  => 1,
        'WARN'  => 2,
        'ERROR' => 3,
    ];
    return $levels[ strtoupper($level) ] ?? 1;
}

/* Log an accessSchema event to the audit table.
 *
 * @param int         $user_id      The user affected (subject).
 * @param string      $action       Action name (e.g. 'access_granted', 'role_added').
 * @param string      $role_path    The full role path (e.g. 'Chronicles/KONY/HST').
 * @param array|null  $context      Additional context (e.g. route, IP), optional.
 * @param int|null    $performed_by The user who initiated the action (default: current user).
 *
 * @return bool True on success, false on failure.
 */
function accessSchema_log_event( $user_id, $action, $role_path, $context = null, $performed_by = null, $level = 'INFO' ) {
    $current_level = accessSchema_get_log_level();
    if ( accessSchema_log_level_priority( $level ) < accessSchema_log_level_priority( $current_level ) ) {
        return false;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'access_audit_log';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Safe, prepared insert to custom audit log table
    $result = $wpdb->insert(
        $table_name,
        [
            'user_id'      => $user_id,
            'action'       => sanitize_text_field( $action ),
            'role_path'    => sanitize_text_field( $role_path ),
            'context'      => is_null( $context ) ? null : maybe_serialize( $context ),
            'performed_by' => $performed_by ?? get_current_user_id(),
            'created_at'   => current_time( 'mysql' ),
        ],
        [ '%d', '%s', '%s', '%s', '%d', '%s' ]
    );

    return $result !== false;
}


/* Role Management Functions 
 */

/* Register roles hierarchically under a group and subkey.
 *
 * @param string $group   Top-level group name (e.g. 'Chronicles').
 * @param string $sub     Sub-level under group (e.g. 'MCKN').
 * @param array  $roles   Final role keys (e.g. ['CM', 'HST', 'Player']).
 */
function accessSchema_register_roles( $group, $sub, $roles ) {
    global $wpdb;
    $table = $wpdb->prefix . 'access_roles';

    $group   = sanitize_text_field( $group );
    $sub     = sanitize_text_field( $sub );
    $roles   = array_map( 'sanitize_text_field', $roles );

    // Insert or get group-level ID
    $group_id = accessSchema_get_or_create_role_node( $group );

    // Insert or get subkey under group
    $sub_id = accessSchema_get_or_create_role_node( $sub, $group_id );

    // Insert roles under sub
    foreach ( $roles as $role ) {
        accessSchema_get_or_create_role_node( $role, $sub_id );
    }
}

/* Check if a role path exists in the registered roles.
 *
 * @param string $role_path e.g. 'Chronicles/MCKN/HST'
 * @return bool True if the role exists, false otherwise.
 */
function accessSchema_role_exists( $role_path ) {
    global $wpdb;
    $table = $wpdb->prefix . 'access_roles';

    $parts = explode( '/', trim( $role_path ) );
    if ( count( $parts ) < 1 ) {
        return false;
    }

    $parent_id = null;
    foreach ( $parts as $part ) {
        $part = sanitize_text_field( $part );
        $id = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE name = %s AND " . ( is_null($parent_id) ? "parent_id IS NULL" : "parent_id = %d" ),
            ...(is_null($parent_id) ? [$part] : [$part, $parent_id])
        ));
        if ( ! $id ) {
            return false;
        }
        $parent_id = $id;
    }

    return true;
}

/* Add a role path to a user’s accessSchema meta with validation.
 *
 * @param int       $user_id      The user to assign the role to.
 * @param string    $role_path    The role path to add (e.g. 'Chronicles/MCKN/HST').
 * @param int|null  $performed_by Optional — who performed the action.
 *
 * @return bool True if added, false if rejected or duplicate.
 */
function accessSchema_add_role( $user_id, $role_path, $performed_by = null ) {
    $role_path = trim( $role_path );

    // Validate that the role is actually registered in the DB
    if ( ! accessSchema_role_exists( $role_path ) ) {
        accessSchema_log_event( $user_id, 'role_add_invalid', $role_path, [
            'reason' => 'role_not_registered'
        ], $performed_by, 'ERROR' );
        return false;
    }

    // Retrieve existing roles assigned to this user
    $roles = get_user_meta( $user_id, 'accessSchema', true );
    if ( ! is_array( $roles ) ) {
        $roles = [];
    }

    // Prevent duplicate role assignment
    if ( in_array( $role_path, $roles, true ) ) {
        accessSchema_log_event( $user_id, 'role_add_skipped', $role_path, [
            'reason' => 'already_assigned'
        ], $performed_by, 'DEBUG' );
        return false;
    }

    // Custom rule hook — can be overridden to prevent conflicting roles
    if ( ! accessSchema_validate_role_assignment( $user_id, $role_path, $roles ) ) {
        accessSchema_log_event( $user_id, 'role_add_blocked', $role_path, [
            'reason' => 'validation_failed',
            'existing_roles' => $roles,
        ], $performed_by, 'WARN' );
        return false;
    }

    // Add role and persist to usermeta
    $roles[] = $role_path;
    update_user_meta( $user_id, 'accessSchema', $roles );

    accessSchema_log_event( $user_id, 'role_added', $role_path, null, $performed_by, 'INFO' );
    return true;
}

/* Remove a role path from a user’s accessSchema meta.
 *
 * @param int       $user_id      The user to remove the role from.
 * @param string    $role_path    The role path to remove (e.g. 'Chronicles/MCKN/HST').
 * @param int|null  $performed_by Optional — who performed the action.
 *
 * @return bool True if removed, false if not found or invalid.
 */
function accessSchema_remove_role( $user_id, $role_path, $performed_by = null ) {
    $role_path = trim( $role_path );

    // Validate that the role is officially registered
    if ( ! accessSchema_role_exists( $role_path ) ) {
        accessSchema_log_event( $user_id, 'role_remove_invalid', $role_path, [
            'reason' => 'role_not_registered'
        ], $performed_by, 'ERROR' );
        return false;
    }

    $roles = get_user_meta( $user_id, 'accessSchema', true );
    if ( ! is_array( $roles ) ) {
        $roles = [];
    }

    // If user doesn't actually have this role
    if ( ! in_array( $role_path, $roles, true ) ) {
        accessSchema_log_event( $user_id, 'role_remove_skipped', $role_path, [
            'reason' => 'not_assigned'
        ], $performed_by, 'DEBUG' );
        return false;
    }

    // Remove the role and update user meta
    $updated_roles = array_values( array_diff( $roles, [ $role_path ] ) );
    update_user_meta( $user_id, 'accessSchema', $updated_roles );

    accessSchema_log_event( $user_id, 'role_removed', $role_path, null, $performed_by, 'INFO' );
    return true;
}

/*  Validate whether a role can be assigned to a user.
 *
 * Extend this to enforce custom constraints (e.g., only one CM role per user).
 *
 * @param int    $user_id        The user ID being assigned a role.
 * @param string $new_role       The role path being assigned (e.g., 'Chronicles/MCKN/CM').
 * @param array  $existing_roles An array of the user's current role paths.
 *
 * @return bool True if the role can be assigned; false otherwise.
 */
function accessSchema_validate_role_assignment( $user_id, $new_role, $existing_roles ) {
    // Example rule (disabled for now):
    // - Block assigning more than one CM role
    /*
    if ( preg_match( '#^Chronicles/[^/]+/CM$#', $new_role ) ) {
        foreach ( $existing_roles as $role ) {
            if ( preg_match( '#^Chronicles/[^/]+/CM$#', $role ) ) {
                return false;
            }
        }
    }
    */

    // Default: allow all
    return true;
}

/* Check if a user has a given role or any of its children (if recursive).
 *
 * @param int       $user_id         The user ID being checked.
 * @param string    $target_path     The target role path (e.g. 'Chronicles/KONY').
 * @param bool      $include_children Whether to include subpaths in the check.
 * @param bool      $log             Whether to log the result of this check (default: true).
 * @param string[]  $context         Optional logging context (e.g. route, IP).
 *
 * @return bool True if match found, false otherwise.
 */
function accessSchema_check_permission( $user_id, $target_path, $include_children = false, $log = true, $context = [] ) {
    $target_path = trim( $target_path );

    if ( ! accessSchema_role_exists( $target_path ) ) {
        if ( $log ) {
            accessSchema_log_event( $user_id, 'role_check_invalid', $target_path, [
                'reason' => 'role_not_registered',
            ], null, 'ERROR' );
        }
        return false;
    }

    $roles = get_user_meta( $user_id, 'accessSchema', true );
    if ( ! is_array( $roles ) ) {
        $roles = [];
    }

    $matched = false;
    foreach ( $roles as $role ) {
        if ( $role === $target_path ) {
            $matched = true;
            break;
        }
        if ( $include_children && str_starts_with( $role, $target_path . '/' ) ) {
            $matched = true;
            break;
        }
    }

    if ( $log ) {
        $context = array_merge( [
            'route' => isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '',
            'ip'    => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
        ], $context );

        accessSchema_log_event(
            $user_id,
            $matched ? 'access_granted' : 'access_denied',
            $target_path,
            $context,
            null,
            $matched ? 'INFO' : 'WARN'
        );
    }

    return $matched;
}

/* Save user roles from the profile update.
 *
 * This function is called when a user profile is updated to save the accessSchema roles.
 * It compares the new roles with existing ones and updates accordingly.
 *
 * @param int   $user_id    The ID of the user being updated.
 * @param array $new_roles  The new roles to assign to the user.
 *
 * @return bool True on success, false on failure.
 */
function accessSchema_save_user_roles( $user_id, $new_roles ) {
    $existing_roles = get_user_meta( $user_id, 'accessSchema', true );
    if ( ! is_array( $existing_roles ) ) {
        $existing_roles = [];
    }

    $to_add = array_diff( $new_roles, $existing_roles );
    $to_remove = array_diff( $existing_roles, $new_roles );

    foreach ( $to_add as $role ) {
        accessSchema_add_role( $user_id, $role );
    }

    foreach ( $to_remove as $role ) {
        accessSchema_remove_role( $user_id, $role );
    }

    return true;
}

/* Insert or retrieve role ID by name and optional parent.
 *
 * @param string   $name       Role name (e.g. 'CM', 'Chronicles').
 * @param int|null $parent_id  Parent role ID or null.
 * @return int                 ID of the role node.
 */
function accessSchema_get_or_create_role_node( $name, $parent_id = null ) {
    global $wpdb;
    $table = $wpdb->prefix . 'access_roles';

    $name = sanitize_text_field( $name );

    $existing_id = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM $table WHERE name = %s AND parent_id " . ( is_null($parent_id) ? "IS NULL" : "= %d" ),
        ...(is_null($parent_id) ? [$name] : [$name, $parent_id])
    ));

    if ( $existing_id ) {
        return (int) $existing_id;
    }

    // Compute full path
    $full_path = $name;
    if ( ! is_null( $parent_id ) ) {
        $parent_path = $wpdb->get_var( $wpdb->prepare(
            "SELECT full_path FROM $table WHERE id = %d",
            $parent_id
        ));
        if ( $parent_path ) {
            $full_path = $parent_path . '/' . $name;
        }
    }

    $wpdb->insert( $table, [
        'name'       => $name,
        'parent_id'  => $parent_id,
        'full_path'  => $full_path,
        'created_at' => current_time( 'mysql' ),
    ], [ '%s', is_null($parent_id) ? 'NULL' : '%d', '%s', '%s' ]);

    return (int) $wpdb->insert_id;
}