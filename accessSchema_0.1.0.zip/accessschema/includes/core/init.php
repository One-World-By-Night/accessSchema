<?php
// File: includes/core/init.php
// @version 0.1.0
// Author: greghacke

defined( 'ABSPATH' ) || exit;

// Plugin init logic
function accessSchema_init() {
    // Init hooks if needed later
}
add_action( 'init', 'accessSchema_init' );