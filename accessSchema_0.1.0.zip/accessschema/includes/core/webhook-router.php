<?php
// File: includes/core/webhook-router.php
// @version 0.1.0
// Author: greghacke
// This file handles the REST API routes for the accessSchema plugin.
// Define this constant in your wp-config.php (do NOT set it here):
// define('ACCESSSCHEMA_API_KEY', 'your-secret-key-here');

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    // Preflight support
    register_rest_route('access-schema/v1', '/.*', [
        'methods' => ['OPTIONS'],
        'callback' => fn() => new WP_REST_Response(null, 204),
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('access-schema/v1', '/register', [
        'methods' => 'POST',
        'callback' => 'accessSchema_api_register_roles',
        'permission_callback' => 'accessSchema_api_permission_check',
    ]);

    register_rest_route('access-schema/v1', '/roles/(?P<user_id>\d+)', [
        'methods' => 'GET',
        'callback' => 'accessSchema_api_get_roles',
        'permission_callback' => 'accessSchema_api_permission_check',
    ]);

    register_rest_route('access-schema/v1', '/grant', [
        'methods' => 'POST',
        'callback' => 'accessSchema_api_grant_role',
        'permission_callback' => 'accessSchema_api_permission_check',
    ]);

    register_rest_route('access-schema/v1', '/revoke', [
        'methods' => 'POST',
        'callback' => 'accessSchema_api_revoke_role',
        'permission_callback' => 'accessSchema_api_permission_check',
    ]);

    register_rest_route('access-schema/v1', '/check', [
        'methods' => 'POST',
        'callback' => 'accessSchema_api_check_permission',
        'permission_callback' => 'accessSchema_api_permission_check',
    ]);
});

function accessSchema_api_permission_check($request) {
    $api_key = $request->get_header('x-api-key');
    $expected_key = defined('ACCESSSCHEMA_API_KEY') ? ACCESSSCHEMA_API_KEY : '';

    if (!$api_key || $api_key !== $expected_key) {
        return new WP_Error('unauthorized', 'Invalid or missing API key', ['status' => 403]);
    }
    return true;
}

function accessSchema_api_register_roles($request) {
    $params = $request->get_json_params();
    $group = sanitize_key($params['group'] ?? '');
    $subkey = sanitize_key($params['subkey'] ?? '');
    $roles = array_filter(array_map('sanitize_text_field', $params['roles'] ?? []));

    if (!$group || !$subkey || empty($roles)) {
        return new WP_Error('invalid_request', 'Missing group, subkey, or roles array.', ['status' => 400]);
    }

    accessSchema_register_roles($group, $subkey, $roles);
    return rest_ensure_response(['registered' => "$group/$subkey", 'roles' => $roles]);
}

function accessSchema_api_get_roles($request) {
    $user_id = (int) $request['user_id'];
    $roles = get_user_meta($user_id, 'accessSchema', true);
    return rest_ensure_response(['user_id' => $user_id, 'roles' => is_array($roles) ? $roles : []]);
}

function accessSchema_api_grant_role($request) {
    $params = $request->get_json_params();
    $user_id = (int) ($params['user_id'] ?? 0);
    $role_path = sanitize_text_field($params['role_path'] ?? '');

    if (!$user_id || !$role_path) {
        return new WP_Error('invalid_request', 'Missing user_id or role_path.', ['status' => 400]);
    }

    $result = accessSchema_add_role($user_id, $role_path);
    return rest_ensure_response(['granted' => $result]);
}

function accessSchema_api_revoke_role($request) {
    $params = $request->get_json_params();
    $user_id = (int) ($params['user_id'] ?? 0);
    $role_path = sanitize_text_field($params['role_path'] ?? '');

    if (!$user_id || !$role_path) {
        return new WP_Error('invalid_request', 'Missing user_id or role_path.', ['status' => 400]);
    }

    $result = accessSchema_remove_role($user_id, $role_path);
    return rest_ensure_response(['revoked' => $result]);
}

function accessSchema_api_check_permission($request) {
    $params = $request->get_json_params();
    $user_id = (int) ($params['user_id'] ?? 0);
    $role_path = sanitize_text_field($params['role_path'] ?? '');
    $include_children = !empty($params['include_children']);

    if (!$user_id || !$role_path) {
        return new WP_Error('invalid_request', 'Missing user_id or role_path.', ['status' => 400]);
    }

    $has_access = accessSchema_check_permission($user_id, $role_path, $include_children);
    return rest_ensure_response(['granted' => $has_access]);
}