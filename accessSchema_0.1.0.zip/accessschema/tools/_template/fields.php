<?php

// File: tools/_template/fields.php
// @version 0.1.0
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;
