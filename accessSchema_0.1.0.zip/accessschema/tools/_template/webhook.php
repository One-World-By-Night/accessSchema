<?php

// File: tools/_template/webhook.php
// @version 0.1.0
// @author greghacke
// @tool _template

defined( 'ABSPATH' ) || exit;

