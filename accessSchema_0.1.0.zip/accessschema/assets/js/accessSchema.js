// File: assets/js/toolkit.js
// @version 0.1.1

document.addEventListener('DOMContentLoaded', function () {
    // Handle role removal via (×) button
    document.querySelectorAll('.remove-role-button').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const rolePath = this.getAttribute('data-role'); // full_path like "Coordinators/Brujah/Subcoordinator"
            const chip = this.closest('.access-role-tag');

            // Create hidden input to record role removal
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'accessSchema_remove_roles[]';
            input.value = rolePath;

            chip.style.display = 'none';
            document.querySelector('form').appendChild(input);
        });
    });

    // Initialize Select2 for multi-select dropdown
    if (window.jQuery && jQuery().select2) {
        jQuery('#accessSchema_add_roles').select2({
            placeholder: 'Select roles to add',
            width: 'resolve'
        });
    }
});