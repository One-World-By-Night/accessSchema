<?php

defined( 'ABSPATH' ) || exit;

add_action(
	'rest_api_init',
	function () {
		// CORS preflight support
		register_rest_route(
			'access-schema/v1',
			'/.*',
			array(
				'methods'             => 'OPTIONS',
				'callback'            => function () {
					return new WP_REST_Response( null, 204 );
				},
				'permission_callback' => '__return_true',
			)
		);

		// Register a group of roles
		register_rest_route(
			'access-schema/v1',
			'/register',
			array(
				'methods'             => 'POST',
				'callback'            => 'accessSchema_api_register_roles',
				'permission_callback' => 'accessSchema_api_permission_check',
				'args'                => array(
					'paths' => array(
						'required'          => true,
						'type'              => 'array',
						'validate_callback' => 'accessSchema_validate_paths_array',
					),
				),
			)
		);

		// Get roles for a user
		register_rest_route(
			'access-schema/v1',
			'/roles',
			array(
				'methods'             => 'POST',
				'callback'            => 'accessSchema_api_get_roles',
				'permission_callback' => 'accessSchema_api_permission_check',
			)
		);

		// Get all registered roles
		register_rest_route(
			'access-schema/v1',
			'/roles/all',
			array(
				'methods'             => 'GET',
				'callback'            => 'accessSchema_api_get_all_roles',
				'permission_callback' => 'accessSchema_api_permission_check',
			)
		);

		// Bulk lookup: all holders for roles matching a SQL LIKE pattern.
		// Accepts 'pattern' (e.g., "chronicle/%/cm") and returns a map of
		// role_path => [ { user_id, display_name, email, user_login }, ... ].
		register_rest_route(
			'access-schema/v1',
			'/roles-by-pattern',
			array(
				'methods'             => 'POST',
				'callback'            => 'accessSchema_api_roles_by_pattern',
				'permission_callback' => 'accessSchema_api_permission_check',
				'args'                => array(
					'pattern' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Grant a role to a user
		register_rest_route(
			'access-schema/v1',
			'/grant',
			array(
				'methods'             => 'POST',
				'callback'            => 'accessSchema_api_grant_role',
				'permission_callback' => 'accessSchema_api_permission_check',
				'args'                => array(
					'role_path' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Revoke a role from a user
		register_rest_route(
			'access-schema/v1',
			'/revoke',
			array(
				'methods'             => 'POST',
				'callback'            => 'accessSchema_api_revoke_role',
				'permission_callback' => 'accessSchema_api_permission_check',
				'args'                => array(
					'role_path' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Check access
		register_rest_route(
			'access-schema/v1',
			'/check',
			array(
				'methods'             => 'POST',
				'callback'            => 'accessSchema_api_check_permission',
				'permission_callback' => 'accessSchema_api_permission_check',
				'args'                => array(
					'role_path'        => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include_children' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);
	}
);

/**
 * Validate the paths array structure for the register endpoint.
 *
 * Ensures that the paths parameter is a non-empty array where each element
 * is an array of non-empty string segments.
 *
 *
 * @param array           $paths   The paths value to validate.
 * @param WP_REST_Request $request The current REST request object.
 * @param string          $key     The parameter key being validated.
 * @return true|WP_Error True if valid, WP_Error on validation failure.
 */
function accessSchema_validate_paths_array( $paths, $request, $key ) {
	if ( ! is_array( $paths ) || empty( $paths ) ) {
		return new WP_Error( 'invalid_paths', 'Paths must be a non-empty array' );
	}

	foreach ( $paths as $path ) {
		if ( ! is_array( $path ) ) {
			return new WP_Error( 'invalid_path_format', 'Each path must be an array of segments' );
		}

		foreach ( $path as $segment ) {
			if ( ! is_string( $segment ) || empty( trim( $segment ) ) ) {
				return new WP_Error( 'invalid_segment', 'Path segments must be non-empty strings' );
			}
		}
	}

	return true;
}

/**
 * Verify API key authorization for a REST API request.
 *
 * Checks the `x-api-key` header against configured read-only and read-write
 * API keys. Enforces rate limiting and logs all access attempts. Read endpoints
 * accept either key type; write endpoints require the read-write key.
 *
 *
 * @param WP_REST_Request $request The current REST request object.
 * @return true|WP_Error True if authorized, WP_Error on failure (403 or 429).
 */
function accessSchema_api_permission_check( $request ) {
	$api_key = $request->get_header( 'x-api-key' );
	$route   = $request->get_route();

	// Get client IP
	$client_ip = accessSchema_get_client_ip();

	// Check rate limiting
	if ( ! accessSchema_check_rate_limit( $client_ip ) ) {
		accessSchema_log_event(
			0,
			'api_rate_limited',
			$route,
			array(
				'ip' => $client_ip,
			),
			null,
			'WARN'
		);
		return new WP_Error( 'rate_limited', 'Too many requests', array( 'status' => 429 ) );
	}

	// Get API keys
	$read_key = get_option( 'accessSchema_api_key_readonly' );
	if ( ! $read_key && defined( 'ACCESSSCHEMA_API_KEY_RO' ) ) {
		$read_key = ACCESSSCHEMA_API_KEY_RO;
	}

	$write_key = get_option( 'accessSchema_api_key_readwrite' );
	if ( ! $write_key && defined( 'ACCESSSCHEMA_API_KEY_RW' ) ) {
		$write_key = ACCESSSCHEMA_API_KEY_RW;
	}

	// Define endpoint permissions
	$read_endpoints = array(
		'/access-schema/v1/roles',
		'/access-schema/v1/roles/all',
		'/access-schema/v1/roles-by-pattern',
		'/access-schema/v1/check',
	);

	$write_endpoints = array(
		'/access-schema/v1/register',
		'/access-schema/v1/grant',
		'/access-schema/v1/revoke',
	);

	$authorized = false;
	$key_type   = '';

	if ( in_array( $route, $read_endpoints, true ) ) {
		if ( $read_key === $api_key ) {
			$authorized = true;
			$key_type   = 'readonly';
		} elseif ( $write_key === $api_key ) {
			$authorized = true;
			$key_type   = 'readwrite';
		}
	} elseif ( in_array( $route, $write_endpoints, true ) ) {
		if ( $write_key === $api_key ) {
			$authorized = true;
			$key_type   = 'readwrite';
		}
	}

	// Log API access
	accessSchema_log_event(
		0,
		$authorized ? 'api_access' : 'api_denied',
		$route,
		array(
			'ip'       => $client_ip,
			'key_type' => $key_type,
			'method'   => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '',
		),
		null,
		$authorized ? 'INFO' : 'WARN'
	);

	if ( ! $authorized ) {
		return new WP_Error( 'unauthorized', 'Invalid or missing API key for this operation', array( 'status' => 403 ) );
	}

	// Add API version header
	add_filter(
		'rest_post_dispatch',
		function ( $response ) {
			$response->header( 'X-AccessSchema-Version', ACCESSSCHEMA_VERSION );
			return $response;
		},
		10,
		1
	);

	return true;
}

/**
 * Check and enforce rate limiting for an identifier.
 *
 * Uses a database-backed sliding window to track request counts. Creates the
 * rate limits table if it does not exist. Cleans up expired entries on each call.
 *
 *
 * @param string $identifier The client identifier to rate limit (typically an IP address).
 * @return bool True if the request is within the rate limit, false if exceeded.
 */
function accessSchema_check_rate_limit( $identifier ) {
	global $wpdb;
	$table = $wpdb->prefix . 'accessSchema_rate_limits';

	// Create table if not exists
	if ( $table !== $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
		$charset_collate = $wpdb->get_charset_collate();
		$sql             = "CREATE TABLE {$table} (
            identifier VARCHAR(64) PRIMARY KEY,
            requests INT DEFAULT 1,
            window_start DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_window_start (window_start)
        ) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	$hash   = md5( $identifier );
	$window = 60; // 1 minute
	/**
	 * Filters the maximum number of API requests allowed per rate limit window.
	 *
	 *
	 * @param int $max_requests The maximum number of requests per window. Default 60.
	 */
	$max_requests = apply_filters( 'accessSchema_api_rate_limit', 60 );

	// Clean old entries
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$table} WHERE window_start < DATE_SUB(NOW(), INTERVAL %d SECOND)",
			$window
		)
	);

	// Check current rate
	$current = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT requests, window_start FROM {$table} 
         WHERE identifier = %s 
         AND window_start > DATE_SUB(NOW(), INTERVAL %d SECOND)",
			$hash,
			$window
		)
	);

	if ( ! $current ) {
		// New window
		$wpdb->insert(
			$table,
			array(
				'identifier' => $hash,
				'requests'   => 1,
			),
			array( '%s', '%d' )
		);
		return true;
	}

	if ( $current->requests >= $max_requests ) {
		return false;
	}

	// Increment counter
	$wpdb->update(
		$table,
		array( 'requests' => $current->requests + 1 ),
		array( 'identifier' => $hash ),
		array( '%d' ),
		array( '%s' )
	);

	return true;
}

// Per-day counter for which resolver path was used. Last 7 days kept.
function accessSchema_track_resolve_path( string $path ): void {
	static $valid = array( 'by_player_id', 'by_id', 'by_email' );
	if ( ! in_array( $path, $valid, true ) ) return;

	$day  = current_time( 'Y-m-d' );
	$stats = get_option( 'accessSchema_resolve_stats', array() );
	if ( ! is_array( $stats ) ) $stats = array();
	if ( ! isset( $stats[ $day ] ) || ! is_array( $stats[ $day ] ) ) $stats[ $day ] = array();
	if ( ! isset( $stats[ $day ][ $path ] ) ) $stats[ $day ][ $path ] = 0;
	$stats[ $day ][ $path ]++;

	// Keep last 7 days only.
	if ( count( $stats ) > 7 ) {
		ksort( $stats );
		$stats = array_slice( $stats, -7, null, true );
	}

	update_option( 'accessSchema_resolve_stats', $stats, false );
}

/**
 * Resolve a WordPress user from request parameters.
 *
 * Preferred: 'player_id' (stable across email changes). Falls back to 'id', then 'email'.
 *
 * @param array $params Associative array with optional 'player_id' (string), 'id' (int), or 'email' (string) keys.
 * @return WP_User|null The resolved user object, or null if not found or invalid.
 */
function accessSchema_resolve_user( $params ) {
	$user = null;
	$path = '';

	if ( ! empty( $params['player_id'] ) ) {
		$path  = 'by_player_id';
		$pid   = sanitize_text_field( $params['player_id'] );
		$users = get_users( array(
			'meta_key'   => 'player_id',
			'meta_value' => $pid,
			'number'     => 1,
			'fields'     => 'all',
		) );
		$user = ! empty( $users ) ? $users[0] : null;
	} elseif ( ! empty( $params['id'] ) ) {
		$path = 'by_id';
		$user = get_user_by( 'id', absint( $params['id'] ) );
	} elseif ( ! empty( $params['email'] ) ) {
		$path = 'by_email';
		$user = get_user_by( 'email', sanitize_email( $params['email'] ) );
	} else {
		return null;
	}

	accessSchema_track_resolve_path( $path );

	if ( $user && user_can( $user->ID, 'read' ) ) {
		return $user;
	}

	return null;
}

/**
 * Handle the REST API request to register role paths.
 *
 * Accepts an array of path segment arrays and registers each one in the role
 * tree within a database transaction. Returns lists of successfully registered
 * and failed paths.
 *
 *
 * @param WP_REST_Request $request The REST request object containing a 'paths' parameter.
 * @return WP_REST_Response|WP_Error Response with 'registered' and 'failed' arrays, or error on transaction failure.
 */
function accessSchema_api_register_roles( $request ) {
	$params = $request->get_json_params();
	$paths  = $params['paths'] ?? array();

	$registered = array();
	$failed     = array();

	global $wpdb;
	$wpdb->query( 'START TRANSACTION' );

	try {
		foreach ( $paths as $path ) {
			if ( ! is_array( $path ) || empty( $path ) ) {
				$failed[] = 'Invalid path format';
				continue;
			}

			$sanitized = array_map( 'sanitize_text_field', $path );
			$result    = accessSchema_register_path( $sanitized );

			if ( $result ) {
				$registered[] = implode( '/', $sanitized );
			} else {
				$failed[] = implode( '/', $sanitized );
			}
		}

		$wpdb->query( 'COMMIT' );

		// Clear cache after bulk registration
		wp_cache_delete( 'all_roles', 'accessSchema' );
	} catch ( Exception $e ) {
		$wpdb->query( 'ROLLBACK' );
		return new WP_Error( 'registration_failed', $e->getMessage(), array( 'status' => 500 ) );
	}

	$response = array( 'registered' => $registered );

	if ( ! empty( $failed ) ) {
		$response['failed'] = $failed;
	}

	return rest_ensure_response( $response );
}

/**
 * Handle the REST API request to get a user's roles.
 *
 * Resolves the user from the request body (by id or email) and returns their
 * assigned role paths. Results are cached for 5 minutes.
 *
 *
 * @param WP_REST_Request $request The REST request object with user identification parameters.
 * @return WP_REST_Response|WP_Error Response with 'email' and 'roles' keys, or error if user not found.
 */
/**
 * REST: bulk lookup of role holders by SQL LIKE pattern.
 *
 * Returns a map of role_path => array of user objects. Single query,
 * cached 5 minutes. Intended for reports that need every holder of
 * every role matching a pattern like "chronicle/%/cm".
 */
function accessSchema_api_roles_by_pattern( $request ) {
	global $wpdb;
	$params  = $request->get_json_params();
	$pattern = isset( $params['pattern'] ) ? sanitize_text_field( $params['pattern'] ) : '';
	if ( '' === $pattern ) {
		return new WP_Error( 'missing_pattern', 'pattern is required.', array( 'status' => 400 ) );
	}

	$cache_key = 'api_roles_by_pattern_' . md5( $pattern );
	$cached    = wp_cache_get( $cache_key, 'accessSchema' );
	if ( false !== $cached ) {
		return rest_ensure_response( $cached );
	}

	$roles_table = $wpdb->prefix . 'accessSchema_roles';
	$ur_table    = $wpdb->prefix . 'accessSchema_user_roles';

	$rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT r.full_path, u.ID AS user_id, u.display_name, u.user_email, u.user_login
		   FROM {$ur_table} ur
		   JOIN {$roles_table} r ON r.id = ur.role_id
		   JOIN {$wpdb->users} u ON u.ID = ur.user_id
		  WHERE r.full_path LIKE %s
		    AND ur.is_active = 1
		    AND r.is_active = 1
		    AND ( ur.expires_at IS NULL OR ur.expires_at > %s )
		  ORDER BY r.full_path",
		$pattern,
		current_time( 'mysql' )
	) );

	$map = array();
	foreach ( $rows as $row ) {
		$map[ $row->full_path ][] = array(
			'user_id'      => (int) $row->user_id,
			'display_name' => $row->display_name,
			'email'        => $row->user_email,
			'user_login'   => $row->user_login,
		);
	}

	$response = array(
		'pattern' => $pattern,
		'roles'   => $map,
		'count'   => count( $rows ),
	);
	wp_cache_set( $cache_key, $response, 'accessSchema', 300 );
	return rest_ensure_response( $response );
}

function accessSchema_api_get_roles( $request ) {
	$params = $request->get_json_params();

	// Reverse lookup: role_path → users who hold that role.
	if ( ! empty( $params['role_path'] ) && empty( $params['email'] ) && empty( $params['id'] ) && empty( $params['player_id'] ) ) {
		$role_path = sanitize_text_field( $params['role_path'] );
		$cache_key = 'api_role_users_' . md5( $role_path );
		$cached    = wp_cache_get( $cache_key, 'accessSchema' );

		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$wp_users = accessSchema_get_users_by_role( $role_path );
		$users    = array();
		foreach ( $wp_users as $u ) {
			$pid     = get_user_meta( $u->ID, 'player_id', true );
			$users[] = array(
				'user_id'      => $u->ID,
				'display_name' => $u->display_name,
				'email'        => $u->user_email,
				'user_login'   => $u->user_login,
				'player_id'    => $pid ? (string) $pid : '',
			);
		}

		$response = array(
			'role_path' => $role_path,
			'users'     => $users,
		);

		wp_cache_set( $cache_key, $response, 'accessSchema', 300 );

		return rest_ensure_response( $response );
	}

	$user = accessSchema_resolve_user( $params );

	if ( ! $user ) {
		return new WP_Error( 'user_not_found', 'User not found by player_id, id, or email.', array( 'status' => 404 ) );
	}

	// Check cache
	$cache_key = 'api_user_roles_' . $user->ID;
	$cached    = wp_cache_get( $cache_key, 'accessSchema' );

	if ( false !== $cached ) {
		return rest_ensure_response( $cached );
	}

	$roles = accessSchema_get_user_roles( $user->ID );

	// Include player_id so client sites can sync it locally.
	$pid = get_user_meta( $user->ID, 'player_id', true );

	$response = array(
		'email'     => $user->user_email,
		'roles'     => is_array( $roles ) ? $roles : array(),
		'player_id' => $pid ? (string) $pid : '',
	);

	wp_cache_set( $cache_key, $response, 'accessSchema', 300 );

	return rest_ensure_response( $response );
}

/**
 * Handle the REST API request to grant a role to a user.
 *
 * Resolves the user, validates the role path and optional expiration date,
 * then assigns the role. Clears the API cache for the affected user.
 *
 *
 * @param WP_REST_Request $request The REST request object with 'role_path' and user identification.
 * @return WP_REST_Response|WP_Error Response with grant result, or error on invalid request.
 */
function accessSchema_api_grant_role( $request ) {
	$params     = $request->get_json_params();
	$user       = accessSchema_resolve_user( $params );
	$role_path  = sanitize_text_field( $params['role_path'] ?? '' );
	$expires_at = isset( $params['expires_at'] ) ? sanitize_text_field( $params['expires_at'] ) : null;

	if ( ! $user || ! $role_path ) {
		return new WP_Error( 'invalid_request', 'Missing user (player_id/id/email) or role_path.', array( 'status' => 400 ) );
	}

	// Validate expiration date if provided
	if ( $expires_at ) {
		$expires_timestamp = strtotime( $expires_at );
		if ( false === $expires_timestamp || $expires_timestamp <= time() ) {
			return new WP_Error( 'invalid_expiration', 'Invalid or past expiration date.', array( 'status' => 400 ) );
		}
		$expires_at = date( 'Y-m-d H:i:s', $expires_timestamp );
	}

	$result = accessSchema_add_role( $user->ID, $role_path, 0, $expires_at );

	// Clear cache
	wp_cache_delete( 'api_user_roles_' . $user->ID, 'accessSchema' );

	$response = array(
		'email'      => $user->user_email,
		'granted'    => $result,
		'expires_at' => $expires_at,
	);

	// If denied by rules engine, include the reason
	if ( ! $result ) {
		$denial = get_transient( 'accessSchema_grant_denial_' . $user->ID . '_' . md5( $role_path ) );
		if ( $denial && is_array( $denial ) ) {
			$response['reason']  = $denial['reason'] ?? '';
			$response['rule_id'] = $denial['rule_id'] ?? null;
			delete_transient( 'accessSchema_grant_denial_' . $user->ID . '_' . md5( $role_path ) );
		}
	}

	return rest_ensure_response( $response );
}

/**
 * Handle the REST API request to revoke a role from a user.
 *
 * Resolves the user and removes the specified role assignment. Clears the
 * API cache for the affected user.
 *
 *
 * @param WP_REST_Request $request The REST request object with 'role_path' and user identification.
 * @return WP_REST_Response|WP_Error Response with revoke result, or error on invalid request.
 */
function accessSchema_api_revoke_role( $request ) {
	$params    = $request->get_json_params();
	$user      = accessSchema_resolve_user( $params );
	$role_path = sanitize_text_field( $params['role_path'] ?? '' );

	if ( ! $user || ! $role_path ) {
		return new WP_Error( 'invalid_request', 'Missing user (player_id/id/email) or role_path.', array( 'status' => 400 ) );
	}

	$result = accessSchema_remove_role( $user->ID, $role_path );

	// Clear cache
	wp_cache_delete( 'api_user_roles_' . $user->ID, 'accessSchema' );

	return rest_ensure_response(
		array(
			'email'   => $user->user_email,
			'revoked' => $result,
		)
	);
}

/**
 * Handle the REST API request to check a user's permission.
 *
 * Resolves the user and checks whether they have access to the specified
 * role path. Supports optional child role inclusion. Results are cached
 * for 5 minutes.
 *
 *
 * @param WP_REST_Request $request The REST request object with 'role_path', optional 'include_children', and user identification.
 * @return WP_REST_Response|WP_Error Response with 'granted' boolean, or error on invalid request.
 */
function accessSchema_api_check_permission( $request ) {
	$params           = $request->get_json_params();
	$user             = accessSchema_resolve_user( $params );
	$role_path        = sanitize_text_field( $params['role_path'] ?? '' );
	$include_children = ! empty( $params['include_children'] );

	if ( ! $user || ! $role_path ) {
		return new WP_Error( 'invalid_request', 'Missing user (player_id/id/email) or role_path.', array( 'status' => 400 ) );
	}

	// Use cached permission check
	$cache_key = sprintf( 'api_perm_%d_%s_%d', $user->ID, md5( $role_path ), $include_children ? 1 : 0 );
	$cached    = wp_cache_get( $cache_key, 'accessSchema' );

	if ( false !== $cached ) {
		return rest_ensure_response(
			array(
				'email'   => $user->user_email,
				'granted' => (bool) $cached,
			)
		);
	}

	$has_access = accessSchema_check_permission( $user->ID, $role_path, $include_children, false );

	wp_cache_set( $cache_key, $has_access, 'accessSchema', 300 );

	return rest_ensure_response(
		array(
			'email'   => $user->user_email,
			'granted' => $has_access,
		)
	);
}

/**
 * Handle the REST API request to get all registered roles.
 *
 * Returns both a flat list and the hierarchical tree of all registered roles.
 * The flat list includes id, name, path, depth, and parent_id for each role.
 *
 *
 * @param WP_REST_Request $request The REST request object.
 * @return WP_REST_Response Response with 'total', 'roles' (flat list), and 'hierarchy' (tree) keys.
 */
function accessSchema_api_get_all_roles( $request ) {
	// Get all roles with hierarchy
	$roles = accessSchema_get_all_roles();

	// Flatten for API response
	$response = array(
		'total'     => 0,
		'roles'     => array(),
		'hierarchy' => $roles,
	);

	// Create flat list with full details
	$flat_roles = array();
	accessSchema_flatten_roles( $roles, $flat_roles );

	$response['roles'] = $flat_roles;
	$response['total'] = count( $flat_roles );

	return rest_ensure_response( $response );
}

/**
 * Recursively flatten a hierarchical role tree into a flat array.
 *
 * Walks through each node and its children, appending a simplified
 * representation (id, name, path, depth, parent_id) to the result array.
 *
 *
 * @param array $nodes  An array of role node arrays, each with optional 'children' key.
 * @param array $result Reference to the flat result array to append to.
 * @return void
 */
function accessSchema_flatten_roles( $nodes, &$result ) {
	foreach ( $nodes as $node ) {
		$result[] = array(
			'id'        => $node['id'],
			'name'      => $node['name'],
			'path'      => $node['full_path'],
			'depth'     => $node['depth'],
			'parent_id' => $node['parent_id'],
		);

		if ( ! empty( $node['children'] ) ) {
			accessSchema_flatten_roles( $node['children'], $result );
		}
	}
}

// Add CORS headers
add_action(
	'rest_api_init',
	function () {
		remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
		add_filter(
			'rest_pre_serve_request',
			function ( $value ) {
				$origin = get_http_origin();
				/**
				 * Filters the list of allowed CORS origins for REST API requests.
				 *
				 * Allows plugins to add or modify the origins permitted to make
				 * cross-origin requests to the Access Schema REST API.
				 *
				 *
				 * @param string[] $allowed_origins List of allowed origin URLs. Default contains the requesting origin.
				 */
				$allowed_origins = apply_filters( 'accessSchema_cors_origins', array( $origin ) );

				if ( in_array( $origin, $allowed_origins, true ) ) {
					header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
				}

				header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS' );
				header( 'Access-Control-Allow-Headers: x-api-key, Content-Type' );
				header( 'Access-Control-Max-Age: 3600' );

				return $value;
			}
		);
	},
	15
);
